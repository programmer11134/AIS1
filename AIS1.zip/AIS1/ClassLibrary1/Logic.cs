﻿using System;
using System.Collections.Generic;

namespace Data
{
    /// <summary>
    /// Класс для управления списком зелий (Варка, Удаление, Фильтр, Сортировка)
    /// </summary>
    public class Logic
    {
        private List<Potion> _potions = new List<Potion>();

        private int _nextId = 1;

        /// <summary>
        /// 1. Крафт зелий
        /// </summary>
        public void Create(string num1, string num2)
        {
            Potion newPotion = new Potion();
            newPotion.Id = _nextId;

            // 1 и 2 — Трава и Вода (Лечебное)
            if ((num1 == "1" && num2 == "2") || (num1 == "2" && num2 == "1"))
            {
                newPotion.Name = "Малое зелье здоровья";
                newPotion.Type = "Лечебное";
                newPotion.Power = 30;
                newPotion.Cost = 15;
            }
            // 3 и 4 — Гриб и Слизь (Яд)
            else if ((num1 == "3" && num2 == "4") || (num1 == "4" && num2 == "3"))
            {
                newPotion.Name = "Кислотный яд";
                newPotion.Type = "Яд";
                newPotion.Power = 55;
                newPotion.Cost = 35;
            }
            // 5 и 2 — Корень и Вода (Бафф)
            else if ((num1 == "5" && num2 == "2") || (num1 == "2" && num2 == "5"))
            {
                newPotion.Name = "Настой сосредоточения";
                newPotion.Type = "Бафф";
                newPotion.Power = 40;
                newPotion.Cost = 25;
            }
            else
            {
                newPotion.Name = "Бесполезная жижа";
                newPotion.Type = "Мусор";
                newPotion.Power = 1;
                newPotion.Cost = 2;
            }

            _potions.Add(newPotion);
            _nextId = _nextId + 1;
        }

        /// <summary>
        /// 3. Все зельки
        /// </summary>
        public List<Potion> ReadAll()
        {
            return _potions;
        }

        /// <summary>
        /// Поиск по id
        /// </summary>
        public Potion ReadById(int id)
        {
            foreach (Potion p in _potions)
            {
                if (p.Id == id)
                {
                    return p;
                }
            }
            return null;
        }

        /// <summary>
        /// Переименование зелья
        /// </summary>
        public bool SetName(int id, string newName)
        {
            Potion potion = ReadById(id);
            if (potion == null)
            {
                return false;
            }

            potion.Name = newName;
            return true;
        }

        /// <summary>
        /// Удаление залья по id
        /// </summary>
        public bool Delete(int id)
        {
            Potion potion = ReadById(id);
            if (potion == null)
            {
                return false;
            }

            _potions.Remove(potion);
            return true;
        }

        /// <summary>
        /// Фильтр зелий по их типу
        /// </summary>
        public List<Potion> Filter(string targetType)
        {
            List<Potion> result = new List<Potion>();
            foreach (Potion p in _potions)
            {
                if (p.Type.ToLower() == targetType.ToLower())
                {
                    result.Add(p);
                }
            }
            return result;
        }

        /// <summary>
        /// Сортировка зелий по мощности
        /// </summary>
        public List<Potion> SortedPot()
        {
            List<Potion> sortedList = new List<Potion>(_potions);

            for (int i = 0; i < sortedList.Count - 1; i+=1)
            {
                for (int j = 0; j < sortedList.Count - 1 - i; j+=1)
                {
                    
                    if (sortedList[j].Power < sortedList[j + 1].Power)
                    {
                        Potion temp = sortedList[j];
                        sortedList[j] = sortedList[j + 1];
                        sortedList[j + 1] = temp;
                    }
                }
            }
            return sortedList;
        }
                public List<string> Ingredients { get; set; } = new List<string>
        {
            "1 - Лечебная трава",
            "2 - Чистая вода",
            "3 - Ядовитый гриб",
            "4 - Слизь кобольда",
            "5 - Корень магии"
        };
                public List<string> PotionTypes { get; set; } = new List<string>
        {
            "Лечебное",
            "Яд",
            "Бафф"
        };


    }
}

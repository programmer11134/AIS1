﻿using System;

namespace Data
{
    /// <summary>
    /// Класс, описывающий одно конкретное зелье
    /// </summary>
    public class Potion
    {
        public int Id { get; set; }
        public string Name { get; set; }
        public string Type { get; set; }
        public int Power { get; set; }
        public int Cost { get; set; }
    }
}

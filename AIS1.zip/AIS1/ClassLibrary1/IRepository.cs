﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Data
{
    public interface IRepository<T> where T : IDomainObject
    {
        void Add(T item);

        T ReadById(int id);

        List<T> ReadAll();
        bool Update(T item);

        bool Delete(int id);
    }
}

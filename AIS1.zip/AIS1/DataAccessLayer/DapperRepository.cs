﻿using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using Dapper;
using Data;

namespace DataAccessLayer
{
    public class DapperRepository : IRepository<Potion>
    {
        private string _connectionString = @"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=|DataDirectory|\PotionDB.mdf;Integrated Security=True";

        private IDbConnection GetConnection()
        {
            return new SqlConnection(_connectionString);
        }

        // 1. Получение всех зелий
        public List<Potion> ReadAll()
        {
            using (IDbConnection db = GetConnection())
            {
                string sqlQuery = "SELECT * FROM Potions";
                return db.Query<Potion>(sqlQuery).ToList();
            }
        }

        // 2. Поиск зелья по ID (Простой LINQ без анонимных объектов)
        public Potion ReadById(int id)
        {
            List<Potion> allPotions = ReadAll();
            // Используем самый простой и понятный LINQ для поиска элемента
            return allPotions.FirstOrDefault(p => p.Id == id);
        }

        // 3. Добавление зелья (Передаем сам объект item напрямую, без new)
        public void Add(Potion item)
        {
            using (IDbConnection db = GetConnection())
            {
                // Просто подставляем значения свойств прямо в строку запроса
                string sqlQuery = "INSERT INTO Potions (Name, Type, Power, Cost) VALUES ('"
                    + item.Name + "', '" + item.Type + "', " + item.Power + ", " + item.Cost + ")";

                db.Execute(sqlQuery);
            }
        }

        // 4. Удаление зелья по ID (Через понятный DynamicParameters)
        public bool Delete(int id)
        {
            using (IDbConnection db = GetConnection())
            {
                // Сначала проверяем, есть ли вообще такое зелье
                Potion potion = ReadById(id);
                if (potion == null)
                {
                    return false;
                }

                // Выполняем удаление по конкретному числу Id
                string sqlQuery = "DELETE FROM Potions WHERE Id = " + id;
                db.Execute(sqlQuery);
                return true;
            }
        }

        // 5. Обновление зелья (Передаем объект item напрямую, без new)
        public bool Update(Potion item)
        {
            using (IDbConnection db = GetConnection())
            {
                string sqlQuery = "UPDATE Potions SET Name = @Name, Type = @Type, Power = @Power, Cost = @Cost WHERE Id = @Id";

                int rowsAffected = db.Execute(sqlQuery, item);
                return rowsAffected > 0;
            }
        }
    }
}

﻿using Data;
using System;
using System.Linq;
using System.Collections.Generic;
using System.Text;

namespace DataAccessLayer
{
    public class EfRepository : IRepository<Potion>
    {
        public void Add(Potion item)
        {
            using (PotionContext context = new PotionContext())
            {
                context.Potions.Add(item);
                context.SaveChanges();
            }
        }

        public Potion ReadById(int id)
        {
            using (PotionContext context = new PotionContext())
            {
                return context.Potions.Find(id);
            }
        }

        public List<Potion> ReadAll()
        {
            using (PotionContext context = new PotionContext())
            {
                return context.Potions.ToList();
            }
        }

        public bool Update(Potion item)
        {
            using (PotionContext context = new PotionContext())
            {
                Potion dbPotion = context.Potions.Find(item.Id);
                if (dbPotion == null)
                {
                    return false;
                }

                dbPotion.Name = item.Name;
                dbPotion.Type = item.Type;
                dbPotion.Power = item.Power;
                dbPotion.Cost = item.Cost;

                context.SaveChanges();
                return true;
            }
        }

        public bool Delete(int id)
        {
            using (PotionContext context = new PotionContext())
            {
                Potion dbPotion = context.Potions.Find(id);
                if (dbPotion == null)
                {
                    return false;
                }

                context.Potions.Remove(dbPotion);
                context.SaveChanges();
                return true;
            }
        }
    }
}

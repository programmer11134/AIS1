﻿using Data;
using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Text;

namespace DataAccessLayer
{
    public class PotionContext : DbContext
    {
        public PotionContext() : base(@"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=|DataDirectory|\PotionDB.mdf;Integrated Security=True")
        {
        }

        public DbSet<Potion> Potions { get; set; }
        public DbSet<Ingredient> Ingredients { get; set; }
    }
}

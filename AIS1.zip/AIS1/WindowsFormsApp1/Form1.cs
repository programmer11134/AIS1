﻿using System;
using System.Windows.Forms;
using Data;

namespace WindowsForms
{
    public partial class Form1 : Form
    {
        private Logic _logic = new Logic();

        public Form1()
        {
            InitializeComponent();

            _logic.Create("1", "2");
            _logic.Create("3", "4");
        }

        private void btnBrew_Click_1(object sender, EventArgs e)
        {
            Form2 cookWindow = new Form2(_logic);

            cookWindow.ShowDialog();
        }

        private void btnShowAll_Click_1(object sender, EventArgs e)
        {
            Form3 labWindow = new Form3(_logic);

            labWindow.ShowDialog();
        }
    }
}

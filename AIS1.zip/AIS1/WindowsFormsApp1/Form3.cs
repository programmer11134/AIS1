﻿using Data;
using System;
using System.Collections.Generic;
using System.Windows.Forms;

namespace WindowsForms
{
    public partial class Form3 : Form
    {
        private Logic _Logic;

        public Form3(Logic def)
        {
            InitializeComponent();
            _Logic = def;

 
            UpdateTable();
        }

        private void UpdateTable()
        {
            dataGridView1.DataSource = null;
            dataGridView1.DataSource = _Logic.ReadAll();
        }
        private void btnDelete_Click(object sender, EventArgs e)
        {
            if (dataGridView1.CurrentRow != null)
            {

                int selectedId = Convert.ToInt32(dataGridView1.CurrentRow.Cells["Id"].Value);


                _Logic.Delete(selectedId);


                UpdateTable();
                comboFilter.Items.Clear();
                foreach (string type in _Logic.PotionTypes)
                {
                    comboFilter.Items.Add(type);
                }

                MessageBox.Show("Зелье успешно вылито из котла.", "Удаление");
            }
            else
            {
                MessageBox.Show("Пожалуйста, выберите строку в таблице мышкой!", "Ошибка");
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            btnDelete_Click(sender, e);
        }


        private void btnRename_Click(object sender, EventArgs e)
        {
            if (dataGridView1.CurrentRow != null)
            {
                int selectedId = Convert.ToInt32(dataGridView1.CurrentRow.Cells["Id"].Value);
                string newName = textName.Text; 

                if (newName == "")
                {
                    MessageBox.Show("Введите новое название!", "Ошибка");
                    return;
                }


                _Logic.SetName(selectedId, newName);

                UpdateTable();
                textName.Clear();

                MessageBox.Show("Название зелья успешно изменено.", "Успех");
            }
            else
            {
                MessageBox.Show("Выберите строку в таблице!", "Ошибка");
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            btnRename_Click(sender, e);
        }

        private void btnFilter_Click(object sender, EventArgs e)
        {
            string targetType = comboFilter.Text;

            if (targetType == "")
            {
                MessageBox.Show("Выберите тип зелья для фильтрации!", "Предупреждение");
                return;
            }

            List<Potion> filteredList = _Logic.Filter(targetType);

            dataGridView1.DataSource = null;
            dataGridView1.DataSource = filteredList;
        }

        private void button3_Click(object sender, EventArgs e)
        {
            btnFilter_Click(sender, e);
        }


        private void btnSort_Click(object sender, EventArgs e)
        {
  
            List<Potion> sortedList = _Logic.SortedPot();

            dataGridView1.DataSource = null;
            dataGridView1.DataSource = sortedList;
        }

        private void button4_Click(object sender, EventArgs e)
        {
            btnSort_Click(sender, e);
        }

        private void btnBack_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}

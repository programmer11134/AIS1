﻿using System;
using System.Windows.Forms;
using Data;

namespace WindowsForms
{
    public partial class Form4 : Form
    {
        private Logic _Logic;

        public Form4(Logic def)
        {
            InitializeComponent();
            _Logic = def;

            UpdateIngredientsTable();
        }

        private void UpdateIngredientsTable()
        {
            dataGridView1.DataSource = null;
            dataGridView1.DataSource = _Logic.ReadAllIngredients();
        }

        private void btnBuy_Click(object sender, EventArgs e)
        {
            if (dataGridView1.CurrentRow == null)
            {
                MessageBox.Show("Пожалуйста, выберите строку в таблице!", "Ошибка");
                return;
            }

            if (!int.TryParse(textAmount.Text, out int amount) || amount <= 0)
            {
                MessageBox.Show("Пожалуйста, введите корректное положительное число!", "Ошибка ввода");
                return;
            }

            try
            {
                int selectedId = Convert.ToInt32(dataGridView1.CurrentRow.Cells[0].Value);

                _Logic.BuyIngredient(selectedId, amount);

                UpdateIngredientsTable();
                textAmount.Clear();

                MessageBox.Show("Запасы ингредиента успешно пополнены!", "Успех", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка при обработке ID: {ex.Message}", "Ошибка");
            }
        }

        private void btnEvaluate_Click(object sender, EventArgs e)
        {
            int totalValue = _Logic.CalculateTotalInventoryValue();

            MessageBox.Show("Общая стоимость ингредиентов на складе: " + totalValue + " монет.", "Отчет");
        }

    }
}

﻿using System;
using System.Windows.Forms;
using Data;

namespace WindowsForms
{
    public partial class Form2 : Form
    {
        private Logic _Logic;

        public Form2(Logic def)
        {
            InitializeComponent();
            _Logic = def;

            comboIng1.Items.Clear();
            comboIng2.Items.Clear();

            string fullText = "ИНГРЕДИЕНТЫ:\n";

            foreach (string item in _Logic.Ingredients)
            {
                string numberOnly = item[0].ToString();

                comboIng1.Items.Add(numberOnly);
                comboIng2.Items.Add(numberOnly);

                fullText = fullText +"\n"+ item + "\n";
            }

            lblIngredientsList.Text = fullText;
        }

        private void btnOk_Click(object sender, EventArgs e)
        {
            string n1 = comboIng1.Text;
            string n2 = comboIng2.Text;

            if (n1 == "" || n2 == "")
            {
                MessageBox.Show("Пожалуйста, выберите оба ингредиента!", "Ошибка");
                return;
            }

            _Logic.Create(n1, n2);

            MessageBox.Show("Зелье успешно сварено!", "Успех");
            this.Close();
        }

        
        private void button1_Click(object sender, EventArgs e)
        {
            btnOk_Click(sender, e);
        }

        private void comboIng1_SelectedIndexChanged(object sender, EventArgs e) { }
        private void comboIng2_SelectedIndexChanged(object sender, EventArgs e) { }
    }
}

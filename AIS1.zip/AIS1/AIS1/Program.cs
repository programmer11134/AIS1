﻿using System;
using System.Collections.Generic;
using Data;

namespace AIS1
{
    class Program
    {
        static void Main(string[] args)
        {
            Logic logic = new Logic();

            logic.Create("1", "2");
            logic.Create("3", "4");

            while (true)
            {
                Console.Clear();
                Console.WriteLine("Меню:");
                Console.WriteLine("1 - Все зелья");
                Console.WriteLine("2 - Сварить новое зелье");
                Console.WriteLine("3 - Переименовать зелье");
                Console.WriteLine("4 - Удалить зелье");
                Console.WriteLine("5 - Фильтр по типу");
                Console.WriteLine("6 - Сортировать по силе");
                Console.WriteLine("0 - Выход");

                string choice = Console.ReadLine();

                switch (choice)
                {
                    case "1":

                        AllPot(logic);
                        break;

                    case "2":
                        Console.WriteLine();
                        Console.WriteLine("Доступные ингредиенты:");
                        Console.WriteLine("1) Лечебная трава");
                        Console.WriteLine("2) Чистая вода");
                        Console.WriteLine("3) Ядовитый гриб");
                        Console.WriteLine("4) Слизь кобольда");
                        Console.WriteLine("5) Корень магии");

                        Console.Write("Введите номер первого ингредиента: ");
                        string num1 = Console.ReadLine();

                        Console.Write("Введите номер второго ингредиента: ");
                        string num2 = Console.ReadLine();

                        logic.Create(num1, num2);
                        Console.WriteLine("Зелье сварено.");
                        break;

                    case "3":
                        AllPot(logic);

                        Console.WriteLine();
                        Console.Write("ID зелья для изменения: ");
                        int idToUpdate = Convert.ToInt32(Console.ReadLine());
                        Console.Write("Новое название: ");
                        string newName = Console.ReadLine();

                        bool isUpdated = logic.SetName(idToUpdate, newName);
                        if (isUpdated == true)
                        {
                            Console.WriteLine("Название изменено.");
                        }
                        else
                        {
                            Console.WriteLine("Не найдено.");
                        }
                        break;

                    case "4":
                        AllPot(logic);

                        Console.WriteLine();
                        Console.Write("ID зелья для удаления: ");
                        int idToDelete = Convert.ToInt32(Console.ReadLine());

                        bool isDeleted = logic.Delete(idToDelete);
                        if (isDeleted == true)
                        {
                            Console.WriteLine("Зелье удалено.");
                        }
                        else
                        {
                            Console.WriteLine("Не найдено.");
                        }
                        break;

                    case "5":
                        Console.WriteLine();
                        Console.Write("Введите тип для поиска (Лечебное, Яд, Бафф): ");
                        string searchType = Console.ReadLine();

                        List<Potion> filtered = logic.Filter(searchType);
                        foreach (Potion p in filtered)
                        {
                            Console.WriteLine("ID: " + p.Id + " | " + p.Name + " [" + p.Type + "]");
                        }
                        break;

                    case "6":
                        Console.WriteLine();
                        Console.WriteLine("Сортировка от сильных к слабым:");
                        List<Potion> sorted = logic.SortedPot();
                        foreach (Potion p in sorted)
                        {
                            Console.WriteLine(p.Name + " (Сила: " + p.Power + ")");
                        }
                        break;

                    case "0":
                        Console.WriteLine("Выход.");
                        return;

                    default:
                        Console.WriteLine("Неверный ввод.");
                        break;

                }
                Console.ReadKey();


            }

        }
        static void AllPot(Logic logic)
        {
            Console.WriteLine();
            Console.WriteLine("Список всех зелий:");

            List<Potion> all = logic.ReadAll();

            foreach (Potion p in all)
            {
                Console.WriteLine("ID: " + p.Id + ", Название: " + p.Name + ", Тип: " + p.Type + ", Сила: " + p.Power + ", Цена: " + p.Cost);
            }
        }

    }
}

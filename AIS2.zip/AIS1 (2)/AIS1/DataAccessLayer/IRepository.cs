﻿using System;
using System.Collections.Generic;
using System.Text;
using Data;

namespace DataAccessLayer
{
    /// <summary>
    ///интерфейс репозитория для выполнения CRUD-операций.
    /// </summary>
    /// <typeparam name="T">Тип объекта домена реализующий интерфейс IDomainObject.</typeparam>
    public interface IRepository<T> where T : IDomainObject
    {
        void Add(T item);

        T ReadById(int id);

        List<T> ReadAll();
        bool Update(T item);

        bool Delete(int id);
    }
}

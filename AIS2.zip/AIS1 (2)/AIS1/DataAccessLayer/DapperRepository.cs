﻿using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using Dapper;
using Data;

namespace DataAccessLayer
{
    public class DapperRepository : IRepository<Potion>
    {
        private string _connectionString = @"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=C:\Users\prudn\Downloads\AIS1 (2)\AIS1\WindowsFormsApp1\PotionDB.mdf;Integrated Security=True";

        private IDbConnection GetConnection()
        {
            return new SqlConnection(_connectionString);
        }

        /// <summary>
        /// Считывает все зелья с бдшки
        /// </summary>
        /// <returns>список всех зелек</returns>
        public List<Potion> ReadAll()
        {
            using (IDbConnection db = GetConnection())
            {
                string sqlQuery = "SELECT * FROM Potions";
                return db.Query<Potion>(sqlQuery).ToList();
            }
        }

        /// <summary>
        /// Ищет конкретное зелье по его уникальному идентификатору среди всех записей.
        /// </summary>
        /// <param name="id">Уникальный id зелья.</param>
        /// <returns>Объект зелья или null</returns>
        public Potion ReadById(int id)
        {
            List<Potion> allPotions = ReadAll();
            return allPotions.FirstOrDefault(p => p.Id == id);
        }

        /// <summary>
        /// Добавляет новое зелье в бд
        /// </summary>
        /// <param name="item">Объект зелья, содержащий данные для добавления.</param>
        public void Add(Potion item)
        {
            using (IDbConnection db = GetConnection())
            {
                string sqlQuery = "INSERT INTO Potions (Name, Type, Power, Cost) VALUES ('"
                    + item.Name + "', '" + item.Type + "', " + item.Power + ", " + item.Cost + ")";

                db.Execute(sqlQuery);
            }
        }

        /// <summary>
        /// Удаляет зелье из базы данных по id.
        /// </summary>
        /// <param name="id">Уникальный id.</param>
        /// <returns>Значение true, если удаление прошло успешно; false, если зелье не найдено.</returns>
        public bool Delete(int id)
        {
            using (IDbConnection db = GetConnection())
            {
                Potion potion = ReadById(id);
                if (potion == null)
                {
                    return false;
                }
                string sqlQuery = "DELETE FROM Potions WHERE Id = " + id;
                db.Execute(sqlQuery);
                return true;
            }
        }

        /// <summary>
        /// Обновляет данные существующего зелья в базе данных
        /// </summary>
        /// <param name="item">Объект зелья с обновленными данными</param>
        /// <returns>Значение true, если хотя бы одна запись была обновлена иначче false.</returns>
        public bool Update(Potion item)
        {
            using (IDbConnection db = GetConnection())
            {
                string sqlQuery = "UPDATE Potions SET Name = @Name, Type = @Type, Power = @Power, Cost = @Cost WHERE Id = @Id";

                int rowsAffected = db.Execute(sqlQuery, item);
                return rowsAffected > 0;
            }
        }
    }
}

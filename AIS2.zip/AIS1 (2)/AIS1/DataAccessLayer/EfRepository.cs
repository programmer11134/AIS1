﻿using Data;
using System;
using System.Linq;
using System.Collections.Generic;
using System.Text;

namespace DataAccessLayer
{
    public class EfRepository : IRepository<Potion>
    {
        /// <summary>
        /// Добавляет новое зелье в бд
        /// </summary>
        /// <param name="item">Объект зелья, который необходимо добавить.</param>
        public void Add(Potion item)
        {
            using (PotionContext context = new PotionContext())
            {
                context.Potions.Add(item);
                context.SaveChanges();
            }
        }

        /// <summary>
        /// Ищет зелье в базе данных по id
        /// </summary>
        /// <param name="id">Уникальный идентификатор зелья.</param>
        /// <returns>Найденный объект зелья или null, если зелье с таким ID не существует.</returns>
        public Potion ReadById(int id)
        {
            using (PotionContext context = new PotionContext())
            {
                return context.Potions.Find(id);
            }
        }

        /// <summary>
        /// полный список всех зелий из базы данных
        /// </summary>
        /// <returns>Список со всеми существующими объектами зелий</returns>
        public List<Potion> ReadAll()
        {
            using (PotionContext context = new PotionContext())
            {
                return context.Potions.ToList();
            }
        }

        /// <summary>
        /// Обновляет свойства существующего зелья в базе данных
        /// </summary>
        /// <param name="item">Объект зелья с обновленными данными</param>
        /// <returns>Значение true, если зелье найдено и успешно обновлено иначе false</returns>
        public bool Update(Potion item)
        {
            using (PotionContext context = new PotionContext())
            {
                Potion dbPotion = context.Potions.Find(item.Id);
                if (dbPotion == null)
                {
                    return false;
                }

                dbPotion.Name = item.Name;
                dbPotion.Type = item.Type;
                dbPotion.Power = item.Power;
                dbPotion.Cost = item.Cost;

                context.SaveChanges();
                return true;
            }
        }

        /// <summary>
        /// Удаляет зелье из базы данных по id
        /// </summary>
        /// <param name="id">Уникальный id</param>
        /// <returns>true если зелье успешно найдено и удалено false если запись не была найдена.</returns>
        public bool Delete(int id)
        {
            using (PotionContext context = new PotionContext())
            {
                Potion dbPotion = context.Potions.Find(id);
                if (dbPotion == null)
                {
                    return false;
                }

                context.Potions.Remove(dbPotion);
                context.SaveChanges();
                return true;
            }
        }
    }
}

﻿using Data;
using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Text;

namespace DataAccessLayer
{
    /// <summary>
    ///класс для поиска расположения бдшки
    /// </summary>
    public class PotionContext : DbContext
    {
        public PotionContext() : base(@"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=C:\Users\prudn\Downloads\AIS1 (2)\AIS1\WindowsFormsApp1\PotionDB.mdf;Integrated Security=True")
        {
        }

        public DbSet<Potion> Potions { get; set; }
        public DbSet<Ingredient> Ingredients { get; set; }
    }
}

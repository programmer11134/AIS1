﻿using System;
using System.Windows.Forms;
using Data;
using BuisnessLog;

namespace WindowsForms
{
    public partial class Form4 : Form
    {
        private Logic _Logic;
        private IngredientService _Ingredientserv;


        public Form4(Logic def, IngredientService ingred)
        {
            InitializeComponent();
            _Logic = def;
            _Ingredientserv = ingred;
            

        UpdateIngredientsTable();
        }

        private void UpdateIngredientsTable()
        {
            dataGridView1.DataSource = null;
            dataGridView1.DataSource = _Ingredientserv.ReadAllIngredients();
        }

        private void btnBuy_Click(object sender, EventArgs e)
        {
            if (dataGridView1.CurrentRow == null)
            {
                MessageBox.Show("Пожалуйста, выберите строку в таблице!", "Ошибка");
                return;
            }

            if (!int.TryParse(textAmount.Text, out int amount) || amount <= 0)
            {
                MessageBox.Show("Пожалуйста, введите корректное положительное число!", "Ошибка ввода");
                return;
            }

            try
            {
                int selectedId = Convert.ToInt32(dataGridView1.CurrentRow.Cells[0].Value);

                _Ingredientserv.BuyIngredient(selectedId, amount);

                UpdateIngredientsTable();
                textAmount.Clear();

                MessageBox.Show("Запасы ингредиента успешно пополнены!", "Успех", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка при обработке ID: {ex.Message}", "Ошибка");
            }
        }

        private void btnEvaluate_Click(object sender, EventArgs e)
        {
            int totalValue = _Ingredientserv.CalculateTotalInventoryValue();

            MessageBox.Show("Общая стоимость ингредиентов на складе: " + totalValue + " монет.", "Отчет");
        }

    }
}

﻿using System;
using System.Windows.Forms;
using Data;
using BuisnessLog;

namespace WindowsForms
{
    public partial class Form2 : Form
    {
        private Logic _Logic;
        private IngredientService _IngredientService;

        public Form2(Logic def, IngredientService ingredientService)
        {
            InitializeComponent();
            InitializeComponent();
            _Logic = def;
            _IngredientService = ingredientService;

            comboIng1.Items.Clear();
            comboIng2.Items.Clear();

            string fullText = "ИНГРЕДИЕНТЫ:\n";

            foreach (Ingredient item in _IngredientService.ReadAllIngredients())
            {
                comboIng1.Items.Add(item.Id);
                comboIng2.Items.Add(item.Id);

                fullText = fullText + $"\n[{item.Id}] {item.Name} (В наличии: {item.Count} шт.)\n";
            }

            lblIngredientsList.Text = fullText;
        }

        private void btnOk_Click(object sender, EventArgs e)
        {
            int n1 = Convert.ToInt32(comboIng1.Text);
            int n2 = Convert.ToInt32(comboIng2.Text);

            if (n1.ToString() == "" || n2.ToString() == "")
            {
                MessageBox.Show("Пожалуйста, выберите оба ингредиента!", "Ошибка");
                return;
            }

            if (!_IngredientService.CheckIngredients(n1, n2))
            {
                MessageBox.Show("Недостаточно ингредиентов на складе для варки этого зелья!", "Ошибка ресурсов");
                return;
            }

            _Logic.Create(n1, n2);

            MessageBox.Show("Зелье успешно сварено! Ингредиенты списаны со склада.", "Успех");
            this.Close();
        }


        private void button1_Click(object sender, EventArgs e)
        {
            btnOk_Click(sender, e);
        }

        private void comboIng1_SelectedIndexChanged(object sender, EventArgs e) { }
        private void comboIng2_SelectedIndexChanged(object sender, EventArgs e) { }
    }
}

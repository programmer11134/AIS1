﻿using System;
using System.Collections.Generic;
using Data;
using DataAccessLayer;

namespace BuisnessLog
{
    public class Logic
    {
        private IRepository<Potion> _potionRepository;
        private IngredientService _ingredientService;

        private int _nextId = 1;

        public Logic(IRepository<Potion> repository, IngredientService ingredientService)
        {
            _potionRepository = repository;
            _ingredientService = ingredientService;
        }

        /// <summary>
        /// 1. Крафт зелий и вычет ингрелиентов
        /// </summary>
        /// <param name="num1">первый ингридиент</param>
        /// <param name="num2">второй ингридиент</param>
        public void Create(int num1, int num2)
        {
            Potion newPotion = BrewPotionByRecipe(num1, num2);
            newPotion.Id = _nextId;

            _potionRepository.Add(newPotion);
            _nextId = _nextId + 1;

            _ingredientService.SpendIngredients(num1, num2);
        }

        /// <summary>
        /// Выбор характеристик зелья по рецепту из двух ингредиентов
        /// </summary>
        /// <param name="num1">первый ингридиент</param>
        /// <param name="num2">второй ингридиент</param>
        /// <returns>созданное зелье по рецепту</returns>
        private Potion BrewPotionByRecipe(int num1, int num2)
        {
            Potion newPotion = new Potion();

            // 1 и 2 — Трава и Вода (Лечебное)
            if ((num1 == 1 && num2 == 2) || (num1 == 2 && num2 == 1))
            {
                newPotion.Name = "heal potion";
                newPotion.Type = "heal";
                newPotion.Power = 30;
                newPotion.Cost = 15;
            }
            // 3 и 4 — Гриб и Слизь (Яд)
            else if ((num1 == 3 && num2 == 4) || (num1 == 4 && num2 == 3))
            {
                newPotion.Name = "acid";
                newPotion.Type = "poison";
                newPotion.Power = 55;
                newPotion.Cost = 35;
            }
            // 5 и 2 — Корень и Вода (Бафф)
            else if ((num1 == 5 && num2 == 2) || (num1 == 2 && num2 == 5))
            {
                newPotion.Name = "Bull heart";
                newPotion.Type = "buff";
                newPotion.Power = 40;
                newPotion.Cost = 25;
            }
            else
            {
                newPotion.Name = "boot";
                newPotion.Type = "trash";
                newPotion.Power = 1;
                newPotion.Cost = 2;
            }

            return newPotion;
        }

        /// <summary>
        /// 3. Все зельки
        /// </summary>
        /// <returns>Выврд списка всех зелий</returns>
        public List<Potion> ReadAll()
        {
            return _potionRepository.ReadAll();
        }

        /// <summary>
        /// Поиск по id
        /// </summary>
        /// <param name="id"> id зелья</param>
        /// <returns>вывод зелья по id</returns>
        public Potion ReadById(int id)
        {
            return _potionRepository.ReadById(id);
        }

        /// <summary>
        /// Переименование зелья
        /// </summary>
        /// <param name="id">id зелья</param>
        /// <param name="newName">новое имя для зельки</param>
        /// <returns>запрос в бд</returns>
        public bool SetName(int id, string newName)
        {
            Potion potion = ReadById(id);
            if (potion == null)
            {
                return false;
            }
            potion.Name = newName;
            return _potionRepository.Update(potion);
        }

        /// <summary>
        /// Удаление залья по id
        /// </summary>
        /// <param name="id">id зелья</param>
        /// <returns>тру или фолс в зависимости от того получилось найти зелье по id или нет</returns>
        public bool Delete(int id)
        {
            return _potionRepository.Delete(id);
        }

        /// <summary>
        /// Фильтр зелий по их типу
        /// </summary>
        /// <param name="targetType">тип выбранного зелья</param>
        /// <returns>отсортированный список зелий</returns>
        public List<Potion> Filter(string targetType)
        {
            List<Potion> result = new List<Potion>();
            List<Potion> allPotions = _potionRepository.ReadAll();
            foreach (Potion p in allPotions)
            {
                if (p.Type.ToLower() == targetType.ToLower())
                {
                    result.Add(p);
                }
            }
            return result;
        }

        /// <summary>
        /// Сортировка зелий по мощности
        /// </summary>
        /// <returns>отсортированный массив зелий</returns>
        public List<Potion> SortedPot()
        {
            List<Potion> sortedList = new List<Potion>(_potionRepository.ReadAll());

            for (int i = 0; i < sortedList.Count - 1; i += 1)
            {
                for (int j = 0; j < sortedList.Count - 1 - i; j += 1)
                {
                    if (sortedList[j].Power < sortedList[j + 1].Power)
                    {
                        Potion temp = sortedList[j];
                        sortedList[j] = sortedList[j + 1];
                        sortedList[j + 1] = temp;
                    }
                }
            }
            return sortedList;
        }

        public List<string> PotionTypes { get; set; } = new List<string>
        {
            "Лечебное",
            "Яд",
            "Бафф"
        };
    }
}

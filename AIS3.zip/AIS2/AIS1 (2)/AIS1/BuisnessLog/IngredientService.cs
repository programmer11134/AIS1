﻿using System.Collections.Generic;
using Data;

namespace BuisnessLog
{
    /// <summary>
    /// Сервис для управления складом ингредиентов
    /// </summary>
    public class IngredientService
    {
        private List<Ingredient> _ingredients = new List<Ingredient>()
        {
            new Ingredient { Id = 1, Name = "Moonlight flower", Count = 5, Cost = 5 },
            new Ingredient { Id = 2, Name = "Sun leaf", Count = 10, Cost = 2 },
            new Ingredient { Id = 3, Name = "Golden root", Count = 3, Cost = 10 },
            new Ingredient { Id = 4, Name = "Fire rose", Count = 2, Cost = 15 },
            new Ingredient { Id = 5, Name = "Magic crystal", Count = 1, Cost = 20 }
        };

        /// <summary>
        /// Вывод списка всех ингредиентов на складе
        /// </summary>
        /// <returns>список ингредиентов</returns>
        public List<Ingredient> ReadAllIngredients()
        {
            return _ingredients;
        }

        /// <summary>
        /// Закупка ингредиентов на склад
        /// </summary>
        /// <param name="id">id ингредиента</param>
        /// <param name="amount">количество для покупки</param>
        /// <returns>тру или фолс получилось изменить количество или нет</returns>
        public bool BuyIngredient(int id, int amount)
        {
            foreach (Ingredient ing in _ingredients)
            {
                if (ing.Id == id)
                {
                    if (amount > 0)
                    {
                        ing.Count = ing.Count + amount;
                        return true;
                    }
                }
            }
            return false;
        }

        /// <summary>
        /// 1-я Бизнес-функция: Проверка наличия ресурсов для проведения крафта
        /// </summary>
        /// <param name="id1">id первого ингредиента</param>
        /// <param name="id2">id второго ингредиента</param>
        /// <returns>тру или фолс хватает ресурсов или нет</returns>
        public bool CheckIngredients(int id1, int id2)
        {
            Ingredient ing1 = null;
            Ingredient ing2 = null;

            foreach (Ingredient ing in _ingredients)
            {
                if (ing.Id == id1)
                {
                    ing1 = ing;
                }
                if (ing.Id == id2)
                {
                    ing2 = ing;
                }
            }

            if (ing1 == null)
            {
                return false;
            }
            if (ing2 == null)
            {
                return false;
            }

            if (id1 == id2)
            {
                if (ing1.Count >= 2)
                {
                    return true;
                }
                else
                {
                    return false;
                }
            }

            if (ing1.Count > 0)
            {
                if (ing2.Count > 0)
                {
                    return true;
                }
            }
            return false;
        }

        /// <summary>
        /// Вычет потраченных при крафте ингредиентов со склада
        /// </summary>
        /// <param name="id1">id первого ингредиента</param>
        /// <param name="id2">id второго ингредиента</param>
        public void SpendIngredients(int id1, int id2)
        {
            foreach (Ingredient ing in _ingredients)
            {
                if (ing.Id == id1)
                {
                    ing.Count = ing.Count - 1;
                }
                if (ing.Id == id2)
                {
                    ing.Count = ing.Count - 1;
                }
            }
        }

        /// <summary>
        /// 2-я Бизнес-функция: расчет общей стоимости всех ресурсов склада
        /// </summary>
        /// <returns>общая стоимость склада</returns>
        public int CalculateTotalInventoryValue()
        {
            int total = 0;
            foreach (Ingredient ing in _ingredients)
            {
                total = total + (ing.Count * ing.Cost);
            }
            return total;
        }
    }
}

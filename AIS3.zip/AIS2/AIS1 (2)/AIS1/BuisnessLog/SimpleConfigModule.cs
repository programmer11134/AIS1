﻿using Ninject.Modules;
using Data;
using DataAccessLayer;

namespace BuisnessLog
{
    public class SimpleConfigModule : NinjectModule
    {
        /// <summary>
        /// Модуль конфигурации Ninject для настройки зависимостей и паттерна Singleton
        /// </summary>
        public override void Load()
        {
            Bind<IRepository<Potion>>().To<EfRepository>().InSingletonScope(); 
            //Bind<IRepository<Potion>>().To<EfRepository>().InSingletonScope();
            Bind<IngredientService>().ToSelf().InSingletonScope();
        }
    }
}
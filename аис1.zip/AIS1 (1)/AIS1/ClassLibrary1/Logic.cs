﻿using System;
using System.Collections.Generic;

namespace Data
{
    public class Logic
    {
        private List<Potion> _potions = new List<Potion>();

        private int _nextId = 1;

        private List<Ingredient> _ingredients = new List<Ingredient>()
        {
            new Ingredient { Id = "1", Name = "Лечебная трава", Count = 5, Cost = 5 },
            new Ingredient { Id = "2", Name = "Чистая вода", Count = 10, Cost = 2 },
            new Ingredient { Id = "3", Name = "Ядовитый гриб", Count = 3, Cost = 10 },
            new Ingredient { Id = "4", Name = "Слизь кобольда", Count = 2, Cost = 15 },
            new Ingredient { Id = "5", Name = "Корень магии", Count = 1, Cost = 20 }
        };

        /// <summary>
        /// 1. Крафт зелий и вычет ингрелиентов
        /// </summary>
        /// <param name="num1">первый ингридиент</param>
        /// <param name="num2">второй ингридиент</param>
        public void Create(string num1, string num2)
        {
            Potion newPotion = new Potion();
            newPotion.Id = _nextId;

            // 1 и 2 — Трава и Вода (Лечебное)
            if ((num1 == "1" && num2 == "2") || (num1 == "2" && num2 == "1"))
            {
                newPotion.Name = "Малое зелье здоровья";
                newPotion.Type = "Лечебное";
                newPotion.Power = 30;
                newPotion.Cost = 15;
            }
            // 3 и 4 — Гриб и Слизь (Яд)
            else if ((num1 == "3" && num2 == "4") || (num1 == "4" && num2 == "3"))
            {
                newPotion.Name = "Кислотный яд";
                newPotion.Type = "Яд";
                newPotion.Power = 55;
                newPotion.Cost = 35;
            }
            // 5 и 2 — Корень и Вода (Бафф)
            else if ((num1 == "5" && num2 == "2") || (num1 == "2" && num2 == "5"))
            {
                newPotion.Name = "Настой сосредоточения";
                newPotion.Type = "Бафф";
                newPotion.Power = 40;
                newPotion.Cost = 25;
            }
            else
            {
                newPotion.Name = "Бесполезная жижа";
                newPotion.Type = "Мусор";
                newPotion.Power = 1;
                newPotion.Cost = 2;
            }

            _potions.Add(newPotion);
            _nextId = _nextId + 1;

            foreach (Ingredient ing in _ingredients)//67
            {
                if (ing.Id == num1)
                {
                    ing.Count = ing.Count - 1;
                }
                if (ing.Id == num2)
                {
                    ing.Count = ing.Count - 1;
                }
            }
        }

        /// <summary>
        /// 3. Все зельки
        /// </summary>
        /// <returns>Выврд списка всех зелий</returns>
        public List<Potion> ReadAll()
        {
            return _potions;
        }

        /// <summary>
        /// Поиск по id
        /// </summary>
        /// <param name="id"> id зелья</param>
        /// <returns>вывод зелья по id</returns>
        public Potion ReadById(int id)
        {
            foreach (Potion p in _potions)
            {
                if (p.Id == id)
                {
                    return p;
                }
            }
            return null;
        }

        /// <summary>
        /// Переименование зелья
        /// </summary>
        /// <param name="id">id зелья</param>
        /// <param name="newName">новое имя для зельки</param>
        /// <returns>тру или фолс в зависимости от того получилось найти зелье по id или нет</returns>
        public bool SetName(int id, string newName)
        {
            Potion potion = ReadById(id);
            if (potion == null)
            {
                return false;
            }
            potion.Name = newName;
            return true;
        }

        /// <summary>
        /// Удаление залья по id
        /// </summary>
        /// <param name="id">id зелья</param>
        /// <returns>тру или фолс в зависимости от того получилось найти зелье по id или нет<</returns>
        public bool Delete(int id)
        {
            Potion potion = ReadById(id);
            if (potion == null)
            {
                return false;
            }
            _potions.Remove(potion);
            return true;
        }

        /// <summary>
        /// Фильтр зелий по их типу
        /// </summary>
        /// <param name="targetType">тип выбранного зелья</param>
        /// <returns>отсортированный список зелий</returns>
        public List<Potion> Filter(string targetType)
        {
            List<Potion> result = new List<Potion>();
            foreach (Potion p in _potions)
            {
                if (p.Type.ToLower() == targetType.ToLower())
                {
                    result.Add(p);
                }
            }
            return result;
        }

        /// <summary>
        /// Сортировка зелий по мощности
        /// </summary>
        /// <returns>отсортированный массив зелий</returns>
        public List<Potion> SortedPot()
        {
            List<Potion> sortedList = new List<Potion>(_potions);

            for (int i = 0; i < sortedList.Count - 1; i += 1)
            {
                for (int j = 0; j < sortedList.Count - 1 - i; j += 1)
                {
                    if (sortedList[j].Power < sortedList[j + 1].Power)
                    {
                        Potion temp = sortedList[j];
                        sortedList[j] = sortedList[j + 1];
                        sortedList[j + 1] = temp;
                    }
                }
            }
            return sortedList;
        }


        /// <summary>
        /// Вывод списка всех ингредиентов на складе
        /// </summary>
        /// <returns>список ингредиентов</returns>
        public List<Ingredient> ReadAllIngredients()
        {
            return _ingredients;
        }

        /// <summary>
        /// Закупка ингредиентов на склад
        /// </summary>
        /// <param name="id">id ингредиента</param>
        /// <param name="amount">количество для покупки</param>
        /// <returns>тру или фолс получилось изменить количество или нет</returns>
        public bool BuyIngredient(string id, int amount)
        {
            foreach (Ingredient ing in _ingredients)
            {
                if (ing.Id == id)
                {
                    if (amount > 0)
                    {
                        ing.Count = ing.Count + amount;
                        return true;
                    }
                }
            }
            return false;
        }

        /// <summary>
        /// 1-я Бизнес-функция: Проверка наличия ресурсов для проведения крафта
        /// </summary>
        /// <param name="id1">id первого ингредиента</param>
        /// <param name="id2">id второго ингредиента</param>
        /// <returns>тру или фолс хватает ресурсов или нет</returns>
        public bool CheckIngredients(string id1, string id2)
        {
            Ingredient ing1 = null;
            Ingredient ing2 = null;

            foreach (Ingredient ing in _ingredients)
            {
                if (ing.Id == id1)
                {
                    ing1 = ing;
                }
                if (ing.Id == id2)
                {
                    ing2 = ing;
                }
            }

            if (ing1 == null)
            {
                return false;
            }
            if (ing2 == null)
            {
                return false;
            }

            if (id1 == id2)
            {
                if (ing1.Count >= 2)
                {
                    return true;
                }
                else
                {
                    return false;
                }
            }

            if (ing1.Count > 0)
            {
                if (ing2.Count > 0)
                {
                    return true;
                }
            }
            return false;
        }

        /// <summary>
        /// 2-я Бизнес-функция: расчет общей стоимости всех ресурсов склада
        /// </summary>
        /// <returns>общая стоимость склада</returns>
        public int CalculateTotalInventoryValue()
        {
            int total = 0;
            foreach (Ingredient ing in _ingredients)
            {
                total = total + (ing.Count * ing.Cost);
            }
            return total;
        }

        public List<string> PotionTypes { get; set; } = new List<string>
        {
            "Лечебное",
            "Яд",
            "Бафф"
        };
    }
}

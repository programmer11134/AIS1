﻿namespace WindowsForms
{
    partial class Form1
    {
        /// <summary>
        /// Обязательная переменная конструктора.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Освободить все используемые ресурсы.
        /// </summary>
        /// <param name="disposing">истинно, если управляемый ресурс должен быть удален; иначе ложно.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Код, автоматически созданный конструктором форм Windows

        /// <summary>
        /// Требуемый метод для поддержки конструктора — не изменяйте 
        /// содержимое этого метода с помощью редактора кода.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            this.btnBrew = new System.Windows.Forms.Button();
            this.btnShowAll = new System.Windows.Forms.Button();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.btnOpenIngredients = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // btnBrew
            // 
            this.btnBrew.Location = new System.Drawing.Point(639, 67);
            this.btnBrew.Name = "btnBrew";
            this.btnBrew.Size = new System.Drawing.Size(149, 45);
            this.btnBrew.TabIndex = 4;
            this.btnBrew.Text = "Сварить";
            this.btnBrew.UseVisualStyleBackColor = true;
            this.btnBrew.Click += new System.EventHandler(this.btnBrew_Click_1);
            // 
            // btnShowAll
            // 
            this.btnShowAll.Location = new System.Drawing.Point(639, 331);
            this.btnShowAll.Name = "btnShowAll";
            this.btnShowAll.Size = new System.Drawing.Size(149, 48);
            this.btnShowAll.TabIndex = 5;
            this.btnShowAll.Text = "Показать все";
            this.btnShowAll.UseVisualStyleBackColor = true;
            this.btnShowAll.Click += new System.EventHandler(this.btnShowAll_Click_1);
            // 
            // pictureBox1
            // 
            this.pictureBox1.ErrorImage = ((System.Drawing.Image)(resources.GetObject("pictureBox1.ErrorImage")));
            this.pictureBox1.Image = global::WindowsFormsApp1.Properties.Resources.на_главную;
            this.pictureBox1.InitialImage = ((System.Drawing.Image)(resources.GetObject("pictureBox1.InitialImage")));
            this.pictureBox1.Location = new System.Drawing.Point(118, 12);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(515, 429);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox1.TabIndex = 13;
            this.pictureBox1.TabStop = false;
            this.pictureBox1.WaitOnLoad = true;
            // 
            // btnOpenIngredients
            // 
            this.btnOpenIngredients.Location = new System.Drawing.Point(639, 192);
            this.btnOpenIngredients.Name = "btnOpenIngredients";
            this.btnOpenIngredients.Size = new System.Drawing.Size(149, 61);
            this.btnOpenIngredients.TabIndex = 14;
            this.btnOpenIngredients.Text = "Склад ингредиентов";
            this.btnOpenIngredients.UseVisualStyleBackColor = true;
            this.btnOpenIngredients.Click += new System.EventHandler(this.btnOpenIngredients_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.btnOpenIngredients);
            this.Controls.Add(this.pictureBox1);
            this.Controls.Add(this.btnShowAll);
            this.Controls.Add(this.btnBrew);
            this.Name = "Form1";
            this.Text = "Form1";
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion
        private System.Windows.Forms.Button btnBrew;
        private System.Windows.Forms.Button btnShowAll;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Button btnOpenIngredients;
    }
}


﻿using System;
using System.Windows.Forms;
using Data;

namespace WindowsForms
{
    public partial class Form4 : Form
    {
        private Logic _Logic;

        public Form4(Logic def)
        {
            InitializeComponent();
            _Logic = def;

            UpdateIngredientsTable();
        }

        private void UpdateIngredientsTable()
        {
            dataGridView1.DataSource = null;
            dataGridView1.DataSource = _Logic.ReadAllIngredients();
        }

        private void btnBuy_Click(object sender, EventArgs e)
        {
            if (dataGridView1.CurrentRow != null)
            {
                string selectedId = dataGridView1.CurrentRow.Cells["Id"].Value.ToString();

                int amount = Convert.ToInt32(textAmount.Text);

                if (amount > 0)
                {
                    _Logic.BuyIngredient(selectedId, amount);
                    UpdateIngredientsTable();
                    textAmount.Clear();

                    MessageBox.Show("Запасы ингредиента успешно пополнены!", "Успех");
                }
                else
                {
                    MessageBox.Show("Пожалуйста, введите положительное число!", "Ошибка ввода");
                }
            }
            else
            {
                MessageBox.Show("Пожалуйста, выберите строку в таблице!", "Ошибка");
            }
        }

        private void btnEvaluate_Click(object sender, EventArgs e)
        {
            int totalValue = _Logic.CalculateTotalInventoryValue();

            MessageBox.Show("Общая стоимость ингредиентов на складе: " + totalValue + " монет.", "Отчет");
        }

    }
}

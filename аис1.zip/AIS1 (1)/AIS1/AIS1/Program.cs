﻿using System;
using System.Collections.Generic;
using Data;

namespace AIS1
{
    class Program
    {
        static void Main(string[] args)
        {
            Logic logic = new Logic();

            // Создаем стартовые зелья для демонстрации работы программы
            logic.Create("1", "2");
            logic.Create("3", "4");

            while (true)
            {
                Console.Clear();
                Console.WriteLine("1 - Все сваренные зелья");
                Console.WriteLine("2 - Сварить новое зелье");
                Console.WriteLine("3 - Изменить название существующего зелья");
                Console.WriteLine("4 - Удалить зелье по его ID");
                Console.WriteLine("5 - Отфильтровать зелья по типу");
                Console.WriteLine("6 - Сортировать зелья по показателю силы");
                Console.WriteLine("7 - Посмотреть ингредиенты");
                Console.WriteLine("8 - Докупить ингредиентов");
                Console.WriteLine("9 - Сумма ингредиентов");
                Console.WriteLine("0 - Выход");

                string choice = Console.ReadLine();

                switch (choice)
                {
                    case "1":
                        AllPot(logic);
                        break;

                    case "2":
                        Console.WriteLine();
                        Console.WriteLine("Текущие остатки ингредиентов:");
                        List<Ingredient> availableIngs = logic.ReadAllIngredients();
                        foreach (Ingredient ing in availableIngs)
                        {
                            Console.WriteLine(ing.Id + ") " + ing.Name + " (В наличии: " + ing.Count + " шт.)");
                        }

                        Console.Write("\nВведите ID первого ингредиента: ");
                        string num1 = Console.ReadLine();

                        Console.Write("Введите ID второго ингредиента: ");
                        string num2 = Console.ReadLine();

                        if (logic.CheckIngredients(num1, num2) == true)
                        {
                            logic.Create(num1, num2);
                            Console.WriteLine("Успех: Зелье сварено, ресурсы списаны.");
                        }
                        else
                        {
                            Console.WriteLine("Ошибка: На складе не хватает нужных материалов!");
                        }
                        break;

                    case "3":
                        AllPot(logic);
                        Console.WriteLine();
                        Console.Write("Введите ID зелья для переименования: ");
                        int idToUpdate = Convert.ToInt32(Console.ReadLine());
                        Console.Write("Введите новое название для зелья: ");
                        string newName = Console.ReadLine();

                        bool isUpdated = logic.SetName(idToUpdate, newName);
                        if (isUpdated == true)
                        {
                            Console.WriteLine("Название успешно изменено.");
                        }
                        else
                        {
                            Console.WriteLine("Зелье с таким ID не найдено.");
                        }
                        break;

                    case "4":
                        AllPot(logic);
                        Console.WriteLine();
                        Console.Write("Введите ID зелья для удаления: ");
                        int idToDelete = Convert.ToInt32(Console.ReadLine());

                        bool isDeleted = logic.Delete(idToDelete);
                        if (isDeleted == true)
                        {
                            Console.WriteLine("Зелье успешно удалено из списка.");
                        }
                        else
                        {
                            Console.WriteLine("Зелье с таким ID не найдено.");
                        }
                        break;

                    case "5":
                        Console.WriteLine();
                        Console.Write("Введите тип для поиска (Лечебное, Яд, Бафф): ");
                        string searchType = Console.ReadLine();

                        List<Potion> filtered = logic.Filter(searchType);
                        foreach (Potion p in filtered)
                        {
                            Console.WriteLine("ID: " + p.Id + " " + p.Name + " тип " + p.Type + "");
                        }
                        break;

                    case "6":
                        Console.WriteLine();
                        Console.WriteLine("Сортировка зелий по убыванию силы:");
                        List<Potion> sorted = logic.SortedPot();
                        foreach (Potion p in sorted)
                        {
                            Console.WriteLine(p.Name + " Показатель силы: " + p.Power + "");
                        }
                        break;

                    case "7":
                        Console.WriteLine("\nСодержимое склада:");
                        List<Ingredient> allIngredients = logic.ReadAllIngredients();
                        foreach (Ingredient ing in allIngredients)
                        {
                            Console.WriteLine("ID: " + ing.Id + " " + ing.Name + " — " + ing.Count + " шт. (Цена закупки: " + ing.Cost + " золотых)");
                        }
                        break;

                    case "8":
                        Console.WriteLine("\nСписок ингредиентов для закупки:");
                        List<Ingredient> listForBuy = logic.ReadAllIngredients();
                        foreach (Ingredient ing in listForBuy)
                        {
                            Console.WriteLine(ing.Id + " - " + ing.Name);
                        }
                        Console.Write("Введите ID товара: ");
                        string buyId = Console.ReadLine();
                        Console.Write("Введите количество для покупки: ");
                        int buyAmount = Convert.ToInt32(Console.ReadLine());

                        if (logic.BuyIngredient(buyId, buyAmount) == true)
                        {
                            Console.WriteLine("Запасы склада пополнены.");
                        }
                        else
                        {
                            Console.WriteLine("Ошибочка(( проверьте корректность ввода ID и количества.");
                        }
                        break;

                    case "9":
                        int totalValue = logic.CalculateTotalInventoryValue();
                        Console.WriteLine("\n Общая рыночная стоимость ингредиентов на складе = " + totalValue + " монет.");
                        break;

                    case "0":
                        Console.WriteLine("Пока.");
                        return;

                    default:
                        Console.WriteLine("Что то не то");
                        break;
                }
                Console.WriteLine("\nНажмите клавишу");
                Console.ReadKey();
            }
        }

        static void AllPot(Logic logic)
        {
            Console.WriteLine();
            Console.WriteLine("Список всех зелий в системе:");
            List<Potion> all = logic.ReadAll();
            foreach (Potion p in all)
            {
                Console.WriteLine("ID: " + p.Id + ", Название: " + p.Name + ", Тип: " + p.Type + ", Сила: " + p.Power + ", Цена: " + p.Cost);
            }
        }
    }
}
